// click(){
  var userOpt={
    STATIC_PATH:"./",//资源根目录
    storeOpt:{
      inputData: {
          ctrl: 'weibo', //'toutiao,weibo,weixin'，'material'
          publishCtrl:'weixin',
      },
    },
    vueOpt:{
      methods:{

      }
    }
  }
  createPop(userOpt);


// }
